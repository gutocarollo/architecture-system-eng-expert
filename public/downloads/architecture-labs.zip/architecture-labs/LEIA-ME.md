# Laboratórios de arquitetura

Esta pasta reúne as cópias de aprendizado usadas nos tutoriais do curso. Os dados das práticas são fictícios. Os manifests identificam os commits históricos e os hashes das funções selecionadas; um resultado local não comprova implantação em produção.

## Comece por um caso

Abra o tutorial no site e execute seus comandos a partir desta pasta, que contém `labs/` e `tasks/`. Consulte o README da família escolhida. Python 3.11 ou mais recente e Node.js precisam estar no PATH. Alguns casos financeiros precisam de OpenSSL 3 e do SDK OpenTelemetry fixado em `labs/architecture/requirements-lock.txt`.

Antes de executar o caso de datas, execute `npm ci --prefix labs/architecture`. O lock fixa o compilador TypeScript usado para executar as funções históricas.

Para preparar o SDK local dos casos que precisam dele, execute `python3 labs/architecture/setup_labs.py`. O comando cria uma pasta `.venv` exclusiva dos laboratórios e baixa as versões fixadas. Ele não configura um exportador de telemetria externo.

Depois dessa preparação, `python3 labs/architecture/run_all.py` executa os quinze casos iniciais e os padrões de objetos. Em uma extração sem Git, o recibo marca a origem como `UNVERSIONED_SOURCE_SNAPSHOT`; os hashes dos arquivos continuam presentes. Use os comandos de cada tutorial para observar e editar o antes/depois.

Os dois casos em `labs/postgres-lineage` precisam das ferramentas PostgreSQL 16 ou mais recente no PATH. O runner inicia um servidor temporário, sem porta TCP, e verifica o próprio diretório antes de escrever. O caso em `labs/airflow-lock-retry` usa dependências locais controladas e não executa uma DAG nem um binário externo.

Os scripts que reextraem fontes de repositórios ou regeneram páginas são ferramentas de manutenção. Eles podem exigir os checkouts originais e não são necessários para executar os exercícios já entregues.

O arquivo `source-manifest.json` contém o SHA-256 de cada arquivo incluído. Preserve a cópia recebida e faça suas alterações em uma pasta separada quando o tutorial pedir.
